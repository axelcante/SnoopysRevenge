#ifndef CONSTANTES_H_INCLUDED
#define CONSTANTES_H_INCLUDED
#define N_COLONNES 20
#define N_LIGNES 10

//D�calage de tableau

#define POSLIGNE 5
#define POSCOLONNE 10
#define BALLPOSX 6
#define BALLPOSY 11
#define SNOOPYPOSX 4
#define SNOOPYPOSY 9

//Librairies
#include <iostream>

#endif // CONSTANTES_H_INCLUDED
